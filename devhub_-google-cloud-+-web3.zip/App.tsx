
import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { GoogleCloudView } from './components/GoogleCloudView';
import { Web3View } from './components/Web3View';
import { DeployerView } from './components/DeployerView';
import { SecretsManagerView } from './components/SecretsManagerView';
import { GithubView } from './components/GithubView';

export type ViewType = 'Dashboard' | 'GoogleCloud' | 'Web3' | 'Deployer' | 'Secrets' | 'GitHub';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>('Dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const renderView = () => {
    if (!isAuthenticated) {
      return <LoginScreen onLogin={() => setIsAuthenticated(true)} />;
    }
    switch (currentView) {
      case 'Dashboard':
        return <Dashboard />;
      case 'GoogleCloud':
        return <GoogleCloudView />;
      case 'Web3':
        return <Web3View />;
      case 'Deployer':
        return <DeployerView />;
      case 'Secrets':
        return <SecretsManagerView />;
      case 'GitHub':
        return <GithubView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100">
      {isAuthenticated && <Sidebar currentView={currentView} setCurrentView={setCurrentView} />}
      <div className="flex-1 flex flex-col overflow-hidden">
        {isAuthenticated && <Header onLogout={() => setIsAuthenticated(false)} />}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-800">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

interface LoginScreenProps {
  onLogin: () => void;
}
const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => (
    <div className="w-full h-full flex flex-col items-center justify-center bg-gray-800">
        <div className="text-center p-8 bg-gray-900 rounded-lg shadow-2xl max-w-md">
            <h1 className="text-4xl font-bold text-brand-primary mb-2">DevHub</h1>
            <p className="text-lg text-gray-300 mb-6">Your Integrated Google Cloud + Web3 Workspace</p>
            <p className="text-gray-400 mb-8">Connect your GitHub account to access your projects, deployments, and integrations.</p>
            <button
                onClick={onLogin}
                className="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center transition-colors duration-200"
            >
                <svg className="w-6 h-6 mr-3" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 4.418 2.865 8.168 6.839 9.49.5.092.682-.217.682-.482 0-.237-.009-.868-.014-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.031-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.203 2.398.1 2.651.64.7 1.03 1.595 1.03 2.688 0 3.848-2.338 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.001 10.001 0 0022 12c0-5.523-4.477-10-10-10z" clipRule="evenodd"></path></svg>
                Sign in with GitHub
            </button>
        </div>
    </div>
);


export default App;
